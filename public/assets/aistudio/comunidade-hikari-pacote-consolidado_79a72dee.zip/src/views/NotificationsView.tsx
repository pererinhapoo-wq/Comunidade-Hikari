import React, { useState, useEffect } from 'react';
import { AppNotification, NotificationPreferences } from '../types';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { BadgeIcon } from '../components/BadgeIcon';
import { 
  Bell, 
  CheckCheck, 
  Heart, 
  MessageSquare, 
  UserPlus, 
  Sparkles,
  ArrowRight,
  Settings2,
  Loader2
} from 'lucide-react';

interface NotificationsViewProps {
  onOpenProfile: (username: string) => void;
  onOpenPost: (postId: string) => void;
  onSelectTab: (tab: any, param?: string) => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({
  onOpenProfile,
  onOpenPost,
  onSelectTab
}) => {
  const { user, refreshUnreadCount } = useAuth();
  const [preferences, setPreferences] = useState<NotificationPreferences>({ likes: true, replies: true, followers: true, badges: true });
  const [preferencesLoading, setPreferencesLoading] = useState<boolean>(true);
  const [preferencesSaving, setPreferencesSaving] = useState<boolean>(false);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const loadNotifications = async () => {
    setIsLoading(true);
    try {
      const res = await api.getNotifications();
      setNotifications(res.notifications || []);
      await refreshUnreadCount();
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadNotifications();
    let active = true;
    api.getNotificationPreferences()
      .then(res => { if (active) setPreferences(res.preferences); })
      .catch(err => console.error('[Notifications] Não foi possível carregar preferências:', err))
      .finally(() => { if (active) setPreferencesLoading(false); });
    return () => { active = false; };
  }, [user?.id]);

  const togglePreference = async (key: keyof NotificationPreferences) => {
    if (preferencesSaving) return;
    const previous = preferences;
    const next = { ...preferences, [key]: !preferences[key] };
    setPreferences(next);
    setPreferencesSaving(true);
    try {
      const result = await api.updateNotificationPreferences(next);
      setPreferences(result.preferences);
    } catch (err) {
      setPreferences(previous);
      console.error('[Notifications] Não foi possível salvar preferências:', err);
    } finally {
      setPreferencesSaving(false);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await api.markAllNotificationsRead();
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      await refreshUnreadCount();
    } catch (err) {
      console.error(err);
    }
  };

  const handleNotificationClick = async (notif: AppNotification) => {
    if (!notif.read) {
      try {
        await api.markNotificationRead(notif.id);
        setNotifications(prev => prev.map(n => n.id === notif.id ? { ...n, read: true } : n));
        await refreshUnreadCount();
      } catch (err) {
        console.error(err);
      }
    }

    if (notif.postId) {
      onOpenPost(notif.postId);
    } else if (notif.type === 'badge') {
      onSelectTab('emblemas');
    } else if (notif.sender) {
      onOpenProfile(notif.sender.username);
    }
  };

  const formatDate = (iso: string) => {
    try {
      const d = new Date(iso);
      return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  };

  const getIcon = (type: AppNotification['type']) => {
    switch (type) {
      case 'like':
        return <Heart className="w-4 h-4 text-rose-400 fill-rose-500/20" />;
      case 'comment':
      case 'reply':
        return <MessageSquare className="w-4 h-4 text-indigo-400" />;
      case 'follow':
        return <UserPlus className="w-4 h-4 text-cyan-400" />;
      case 'badge':
        return <Sparkles className="w-4 h-4 text-amber-400" />;
      default:
        return <Bell className="w-4 h-4 text-slate-400" />;
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      
      {/* Header */}
      <div className="flex items-center justify-between border-b border-white/5 pb-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white font-display">
            Notificações
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Interações, novos seguidores e emblemas desbloqueados
          </p>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={handleMarkAllRead}
            className="px-3 py-1.5 text-xs font-medium text-indigo-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <CheckCheck className="w-3.5 h-3.5" />
            <span>Marcar todas como lidas</span>
          </button>
        )}
      </div>

      {/* Per-account notification preferences */}
      <section className="rounded-2xl bg-[#0E1322] border border-white/5 overflow-hidden">
        <div className="px-4 py-3 border-b border-white/5 flex items-center gap-2">
          <Settings2 className="w-4 h-4 text-indigo-300" />
          <div className="flex-1">
            <h2 className="text-sm font-semibold text-white">Preferências de notificações</h2>
            <p className="text-[11px] text-slate-400 mt-0.5">As escolhas ficam salvas na sua conta.</p>
          </div>
          {(preferencesLoading || preferencesSaving) && <Loader2 className="w-4 h-4 animate-spin text-slate-400" />}
        </div>
        {([
          ['likes', 'Curtidas', 'Quando alguém curtir suas publicações ou comentários.'],
          ['replies', 'Comentários e respostas', 'Quando alguém comentar ou responder ao seu conteúdo.'],
          ['followers', 'Novos seguidores', 'Quando alguém começar a seguir você.'],
          ['badges', 'Emblemas', 'Quando você conquistar um emblema.']
        ] as Array<[keyof NotificationPreferences, string, string]>).map(([key, title, description], index, list) => (
          <div key={key} className={`px-4 py-3 flex items-center gap-3 ${index < list.length - 1 ? 'border-b border-white/5' : ''}`}>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-white">{title}</p>
              <p className="text-[11px] text-slate-400 mt-0.5">{description}</p>
            </div>
            <button
              type="button"
              role="switch"
              aria-label={title}
              aria-checked={preferences[key]}
              disabled={preferencesLoading || preferencesSaving}
              onClick={() => togglePreference(key)}
              className={`relative h-6 w-11 shrink-0 rounded-full transition-colors disabled:opacity-50 ${preferences[key] ? 'bg-indigo-500' : 'bg-slate-700'}`}
            >
              <span className={`absolute top-1 h-4 w-4 rounded-full bg-white transition-all ${preferences[key] ? 'left-6' : 'left-1'}`} />
            </button>
          </div>
        ))}
      </section>

      {/* Notifications List */}
      {isLoading ? (
        <div className="py-12 text-center text-xs text-slate-400">
          Carregando notificações...
        </div>
      ) : notifications.length === 0 ? (
        <div className="p-12 rounded-2xl bg-[#0E1322] border border-white/5 text-center space-y-2">
          <Bell className="w-8 h-8 text-slate-600 mx-auto" />
          <h3 className="text-sm font-semibold text-slate-300">
            Tudo limpo por aqui!
          </h3>
          <p className="text-xs text-slate-500">
            Você receberá notificações sempre que outros membros interagirem com você.
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {notifications.map(n => (
            <div
              key={n.id}
              onClick={() => handleNotificationClick(n)}
              className={`p-4 rounded-xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                n.read
                  ? 'bg-[#0E1322] border-white/5 hover:border-white/10'
                  : 'bg-[#12192E] border-indigo-500/30 hover:border-indigo-500/60 shadow-md shadow-indigo-950/20'
              }`}
            >
              <div className="relative shrink-0 mt-0.5">
                {n.sender?.avatarUrl ? (
                  <img src={n.sender.avatarUrl} alt="" className="h-10 w-10 rounded-full border border-white/10 object-cover bg-slate-800" />
                ) : (
                  <div className="p-3 rounded-full bg-white/5">{getIcon(n.type)}</div>
                )}
                {n.sender?.avatarUrl && (
                  <span className="absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full border border-[#0E1322] bg-[#171E32]">{getIcon(n.type)}</span>
                )}
              </div>

              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="font-semibold text-xs text-white">
                      {n.sender?.displayName || n.title}
                    </span>
                    {n.sender?.displayName && <span className="text-[10px] text-slate-400">· {n.title}</span>}
                    {!n.read && (
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                    )}
                  </div>
                  <span className="text-[10px] text-slate-500 tabular-nums">
                    {formatDate(n.createdAt)}
                  </span>
                </div>

                <p className="text-xs text-slate-300">
                  {n.message}
                </p>

                {n.badge && (
                  <div className="mt-2 inline-flex items-center gap-2 p-1.5 pr-3 rounded-lg bg-white/5 border border-white/5">
                    <BadgeIcon badge={n.badge} size="sm" />
                    <span className="text-xs text-amber-300 font-medium">
                      {n.badge.name}
                    </span>
                  </div>
                )}
              </div>

              <ArrowRight className="w-4 h-4 text-slate-600 self-center shrink-0" />
            </div>
          ))}
        </div>
      )}

    </div>
  );
};
