# Revisão da Etapa B — Comunidade Hikari

Esta cópia foi revisada a partir do ZIP recebido. Nenhuma tela foi alterada e nenhuma ação de GitHub ou deploy foi executada.

## Correção aplicada

- `server.ts`: a listagem de seguidores/seguindo agora também oculta cada perfil que tenha bloqueado o usuário autenticado. A checagem anterior já escondia os perfis bloqueados pelo usuário atual e bloqueava a listagem quando o próprio perfil-alvo tinha bloqueio mútuo; faltava aplicar a direção inversa a cada integrante da lista.

## Observações da auditoria

- O script `scripts/test-etapa-b.ts` é majoritariamente um conjunto de verificações diretas do banco e de funções auxiliares; ele não faz chamadas HTTP reais aos endpoints. Portanto, seus resultados não comprovam sozinhos o comportamento completo das rotas.
- A instalação das dependências não terminou dentro do tempo disponível neste ambiente. Por isso, `npm run lint`, `npm run test:security`, `npm run test:etapa-b` e `npm run build` não foram executados nesta revisão e não são declarados como aprovados aqui.
- O arquivo `data/hikari.json` foi preservado; os testes não foram executados nesta cópia durante a revisão.
- Nenhuma interface da Etapa C foi implementada.

## Arquivo alterado

- `server.ts`
